package com.airil.rillrebirth

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object ReminderScheduler {
    fun scheduleAll(context: Context) {
        val prefs = context.getSharedPreferences("rill_data", Context.MODE_PRIVATE)
        val tasks = TaskStore.load(context)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        tasks.forEach { task ->
            val id = task.id
            val pi = PendingIntent.getBroadcast(
                context, id,
                Intent(context, ReminderReceiver::class.java)
                    .putExtra("task_id", id)
                    .putExtra("task_name", task.name),
                PendingIntent.FLAG_UPDATE_CURRENT or if (android.os.Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
            )
            alarm.cancel(pi)
            if (prefs.getBoolean("reminders_enabled", true) && task.reminderEnabled && task.time.isNotBlank()) {
                val parts = task.time.split(":")
                if (parts.size == 2) {
                    val hour = parts[0].toIntOrNull() ?: return@forEach
                    val minute = parts[1].toIntOrNull() ?: return@forEach
                    if (hour !in 0..23 || minute !in 0..59) return@forEach
                    val cal = Calendar.getInstance().apply {
                        set(Calendar.HOUR_OF_DAY, hour)
                        set(Calendar.MINUTE, minute)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                        if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
                    }
                    alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
                }
            }
        }
    }
}
