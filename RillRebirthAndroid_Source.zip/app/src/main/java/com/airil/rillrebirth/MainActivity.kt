package com.airil.rillrebirth

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(246, 248, 247)
    private val ink = Color.rgb(35, 48, 65)
    private val green = Color.rgb(46, 125, 104)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var selectedTab = "Hari ini"
    private var tasks = mutableListOf<RillTask>()
    private var done = mutableSetOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tasks = TaskStore.load(this)
        done = TaskStore.doneToday(this)
        createNotificationChannel()
        render()
        ReminderScheduler.scheduleAll(this)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, bold: Boolean = false, color: Int = ink): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(2), dp(4), dp(2), dp(4))
        }
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply { text = label; setOnClickListener { action() } }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(10), dp(14), dp(10))
        setBackgroundColor(Color.WHITE)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, dp(5), 0, dp(5))
        layoutParams = lp
    }

    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(12))
            setBackgroundColor(Color.WHITE)
        }
        header.addView(text("RILL REBIRTH", 23f, true))
        header.addView(text("DAILY SYSTEM · Pelan-pelan, konsisten.", 12f, false, Color.DKGRAY))
        root.addView(header)
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            setBackgroundColor(Color.WHITE)
        }
        listOf("Hari ini", "Riwayat", "Statistik", "Jadwal").forEach { tab ->
            val b = Button(this).apply {
                text = tab
                textSize = 11f
                isAllCaps = false
                setPadding(dp(3), 0, dp(3), 0)
                setOnClickListener { selectedTab = tab; render() }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        root.addView(nav)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(18))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        when (selectedTab) {
            "Hari ini" -> showToday()
            "Riwayat" -> showHistory()
            "Statistik" -> showStats()
            "Jadwal" -> showSchedule()
        }
        setContentView(root)
    }

    private fun showToday() {
        val currentXp = TaskStore.xpFor(this, done)
        val totalXp = TaskStore.totalXp(this)
        val level = totalXp / 100 + 1
        val progress = if (tasks.isEmpty()) 0 else (done.size * 100 / tasks.size)
        val overview = card()
        overview.addView(text("Progres hari ini", 17f, true))
        overview.addView(text("$progress% selesai", 28f, true, green))
        overview.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; this.progress = progress
        }, LinearLayout.LayoutParams(-1, dp(12)))
        overview.addView(text("${done.size} dari ${tasks.size} kegiatan · +$currentXp EXP hari ini", 13f))
        overview.addView(text("Level $level · $totalXp EXP terkumpul", 13f, true))
        content.addView(overview)

        content.addView(text("CHECKLIST HARIAN", 15f, true))
        tasks.sortedBy { it.time }.forEach { task ->
            val row = card()
            val check = CheckBox(this).apply {
                text = "${task.name}\n${task.time} · ${task.category} · ${task.xp} EXP"
                textSize = 14f
                isChecked = done.contains(task.id)
                setOnCheckedChangeListener { _, checked ->
                    if (checked) done.add(task.id) else done.remove(task.id)
                    TaskStore.saveDone(this@MainActivity, done)
                    render()
                }
            }
            row.addView(check)
            content.addView(row)
        }
        content.addView(button("Evaluasi malam", { showReviewDialog() }))
        content.addView(text("Progres disimpan lokal di perangkat ini.", 12f, false, Color.DKGRAY))
    }

    private fun showReviewDialog() {
        val input = EditText(this).apply { hint = "Apa yang berhasil hari ini? Apa yang mau diperbaiki?" }
        AlertDialog.Builder(this).setTitle("Evaluasi hari ini").setView(input)
            .setPositiveButton("Simpan") { _, _ ->
                getSharedPreferences("rill_data", Context.MODE_PRIVATE).edit()
                    .putString("review_${TaskStore.today()}", input.text.toString()).apply()
                Toast.makeText(this, "Evaluasi tersimpan.", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Batal", null).show()
    }

    private fun showHistory() {
        val c = card()
        c.addView(text("Riwayat terbaru", 18f, true))
        val history = TaskStore.historySummary(this)
        if (history.isEmpty()) c.addView(text("Belum ada riwayat. Centang kegiatan untuk mulai mencatat progres.", 14f))
        else history.forEach { c.addView(text(it, 14f)) }
        content.addView(c)
        content.addView(text("Riwayat dihitung dari tanggal lokal perangkat.", 12f, false, Color.DKGRAY))
    }

    private fun showStats() {
        val c = card()
        c.addView(text("Statistik 7 hari terakhir", 18f, true))
        TaskStore.weeklyCounts(this).forEach { (date, count) ->
            c.addView(text("$date    $count kegiatan", 14f))
            c.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = tasks.size.coerceAtLeast(1)
                progress = count
            }, LinearLayout.LayoutParams(-1, dp(8)))
        }
        content.addView(c)
        content.addView(text("Catatan: statistik menghitung kegiatan yang ditandai selesai per hari.", 12f, false, Color.DKGRAY))
    }

    private fun showSchedule() {
        content.addView(text("EDIT JADWAL", 17f, true))
        content.addView(text("Pilih kegiatan untuk mengubah nama, waktu, kategori, EXP, dan pengingat.", 13f))
        content.addView(button("Tambah kegiatan", { editTask(null) }))
        content.addView(button("Pengingat global: ${if (getSharedPreferences("rill_data",0).getBoolean("reminders_enabled", true)) "Aktif" else "Nonaktif"}", {
            val prefs = getSharedPreferences("rill_data", 0)
            val enabled = !prefs.getBoolean("reminders_enabled", true)
            prefs.edit().putBoolean("reminders_enabled", enabled).apply()
            ReminderScheduler.scheduleAll(this)
            render()
        }))
        tasks.forEach { task ->
            content.addView(button("${task.time} · ${task.name}  ✎", { editTask(task) }))
        }
    }

    private fun editTask(existing: RillTask?) {
        val task = existing ?: RillTask((tasks.maxOfOrNull { it.id } ?: 0) + 1, "", "18:00", "Umum", 10, false)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), dp(4))
        }
        val name = EditText(this).apply { hint = "Nama kegiatan"; setText(task.name) }
        val time = EditText(this).apply { hint = "HH:MM"; setText(task.time) }
        val category = EditText(this).apply { hint = "Kategori"; setText(task.category) }
        val xp = EditText(this).apply { hint = "EXP (angka)"; setText(task.xp.toString()); inputType = 2 }
        val reminder = CheckBox(this).apply { text = "Aktifkan pengingat harian"; isChecked = task.reminderEnabled }
        box.addView(name); box.addView(time); box.addView(category); box.addView(xp); box.addView(reminder)
        AlertDialog.Builder(this).setTitle(if (existing == null) "Tambah kegiatan" else "Edit kegiatan")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                val timeValue = time.text.toString().trim()
                val validTime = Regex("^([01]?[0-9]|2[0-3]):[0-5][0-9]$").matches(timeValue)
                val taskName = name.text.toString().trim()
                if (taskName.isBlank() || !validTime) {
                    Toast.makeText(this, "Isi nama dan waktu HH:MM yang valid.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                task.name = taskName
                task.time = String.format(Locale.US, "%02d:%02d", timeValue.substringBefore(":").toInt(), timeValue.substringAfter(":").toInt())
                task.category = category.text.toString().ifBlank { "Umum" }
                task.xp = (xp.text.toString().toIntOrNull() ?: 10).coerceIn(0, 500)
                task.reminderEnabled = reminder.isChecked
                if (existing == null) tasks.add(task)
                TaskStore.save(this, tasks)
                ReminderScheduler.scheduleAll(this)
                render()
            }.setNegativeButton("Batal", null)
            .setNeutralButton(if (existing != null) "Hapus" else "Tutup") { _, _ ->
                if (existing != null) {
                    tasks.removeAll { it.id == task.id }
                    done.remove(task.id)
                    TaskStore.save(this, tasks)
                    TaskStore.saveDone(this, done)
                    ReminderScheduler.scheduleAll(this)
                    render()
                }
            }.show()
    }

    private fun createNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val channel = android.app.NotificationChannel("rill_reminders", "Pengingat Rill Rebirth", android.app.NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(android.app.NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
