# Rill Rebirth — Android project

Aplikasi Android native ringan untuk checklist harian, EXP/level, riwayat, statistik 7 hari, edit jadwal, dan pengingat lokal.

## Target
- Android 6.0+ (minSdk 23); dirancang agar kompatibel dengan Android 10.
- Tidak memakai internet atau akun.
- Data disimpan lokal di SharedPreferences.
- Package: `com.airil.rillrebirth`

## Build APK
1. Pasang Android Studio di komputer.
2. Buka folder `RillRebirthAndroid` melalui Android Studio.
3. Izinkan Gradle mengunduh Android Gradle Plugin/Kotlin plugin dan Android SDK yang diperlukan. Build pertama memerlukan internet.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug biasanya dibuat di `app/build/outputs/apk/debug/app-debug.apk`.
6. Pindahkan APK ke HP, buka file, dan izinkan instalasi dari sumber tersebut jika Android memintanya.

## Catatan build
Berkas sumber ini belum dikompilasi atau diuji pada perangkat Android dalam lingkungan pembuatannya. Jadi, jangan anggap APK sudah tersedia sebelum build sukses. Android SDK dan Gradle tidak selalu tersedia di lingkungan chat.

## Pengujian penyimpanan permanen
1. Instal dan buka aplikasi.
2. Centang 2 kegiatan; pastikan progres dan EXP berubah.
3. Tutup aplikasi sepenuhnya (hapus dari Recent Apps), lalu buka lagi. Centang dan EXP harus tetap ada.
4. Mulai ulang HP, buka lagi, dan periksa progres.
5. Buka **Riwayat** dan **Statistik** untuk memeriksa catatan hari ini.
6. Jangan menghapus data aplikasi atau meng-uninstall saat menguji, karena data lokal dapat terhapus.

## Pengingat
- Buka tab **Jadwal**, pilih kegiatan, aktifkan pengingat, dan simpan.
- Aktifkan notifikasi aplikasi di pengaturan Android jika diperlukan.
- Android/MIUI dapat membatasi alarm latar belakang atau notifikasi. Periksa izin notifikasi dan penghematan baterai jika pengingat tidak muncul tepat waktu.
- Pengingat menggunakan alarm harian yang tidak presisi (inexact), jadi notifikasi bisa sedikit terlambat.

## Backup dan batasan
Versi awal ini belum memiliki ekspor/impor backup. Data lokal tidak tersinkron ke cloud. Menghapus aplikasi/data aplikasi dapat menghapus progres.

## Build from a phone with GitHub Actions
A workflow file is included at `.github/workflows/build-apk.yml`. Upload the project files to a GitHub repository, then open the Actions tab and run **Build Rill Rebirth APK**. After a successful run, download the `Rill-Rebirth-debug-APK` artifact. GitHub account sign-in and internet are required. GitHub Actions availability and usage limits depend on account/repository settings.

This workflow is a build setup, not proof that the project compiles. The first build must succeed in GitHub Actions before the APK can be considered generated.
